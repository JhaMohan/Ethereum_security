const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Weak Ramdomness", () => {
  let deployer, attacker, user;

  beforeEach(async () => {
    [deployer, attacker, user] = await ethers.getSigners();

    const Lottery = await ethers.getContractFactory("Lottery", deployer);
    this.lottery = await Lottery.deploy();

    const LotterAttack = await ethers.getContractFactory(
      "LotteryAttacker",
      attacker
    );
    this.lotteryAttack = await LotterAttack.deploy(this.lottery.address);
  });

  describe.skip("Lottery", () => {
    describe("with bets open", () => {
      it("user should able to bet", async () => {
        await this.lottery
          .connect(user)
          .placeBet(5, { value: ethers.utils.parseEther("10") });

        expect(await this.lottery.bets(user.address)).to.eq(5);
      });
      it("should revert if user place more than 1 bet", async () => {
        await this.lottery
          .connect(user)
          .placeBet(5, { value: ethers.utils.parseEther("10") });
        await expect(
          this.lottery
            .connect(user)
            .placeBet(6, { value: ethers.utils.parseEther("10") })
        ).to.be.revertedWith("bet only once");
      });
      it("should revert if bet != 10 eth", async () => {
        await expect(
          this.lottery
            .connect(user)
            .placeBet(6, { value: ethers.utils.parseEther("5") })
        ).to.be.revertedWith("Bet cost: 10 ether");

        await expect(
          this.lottery
            .connect(user)
            .placeBet(6, { value: ethers.utils.parseEther("15") })
        ).to.be.revertedWith("Bet cost: 10 ether");
      });

      it("should revert if bet number not > 0", async () => {
        await expect(
          this.lottery
            .connect(user)
            .placeBet(0, { value: ethers.utils.parseEther("10") })
        ).to.be.revertedWith("number should be between 1 and 255");
      });
    });
  });

  describe.skip("With bets closed", () => {
    it("Should revert if a user place bet", async () => {
      await this.lottery.endLottery();
      await expect(
        this.lottery
          .connect(user)
          .placeBet(54, { value: ethers.utils.parseEther("10") })
      ).to.be.revertedWith("bets are closed");
    });

    it("should allow winner to withdraw prize", async () => {
      await this.lottery
        .connect(user)
        .placeBet(5, { value: ethers.utils.parseEther("10") });
      await this.lottery
        .connect(attacker)
        .placeBet(150, { value: ethers.utils.parseEther("10") });
      await this.lottery.placeBet(75, { value: ethers.utils.parseEther("10") });

      let winningNumber = 0;

      while (winningNumber != 5) {
        await this.lottery.endLottery();
        winningNumber = await this.lottery.winnerNumber();
        // console.log(winningNumber);
      }

      await expect(
        this.lottery.connect(attacker).withdrawPrize()
      ).to.be.revertedWith("you are not the winner");

      const initalBalance = await ethers.provider.getBalance(user.address);
      await this.lottery.connect(user).withdrawPrize();
      const finalBalance = await ethers.provider.getBalance(user.address);
      expect(finalBalance).to.be.gt(initalBalance);
    });
  });

  describe("Attack", () => {
    it.skip("A miner can temper the result", async () => {
      await this.lottery
        .connect(attacker)
        .placeBet(5, { value: ethers.utils.parseEther("10") });
      await this.lottery
        .connect(user)
        .placeBet(150, { value: ethers.utils.parseEther("10") });
      await this.lottery.placeBet(75, { value: ethers.utils.parseEther("10") });

      await ethers.provider.send("evm_setNextBlockTimestamp", [1658602062]);
      let winningNumber = 0;

      while (winningNumber != 5) {
        await this.lottery.endLottery();
        winningNumber = await this.lottery.winnerNumber();
        console.log(winningNumber);
      }
      //   console.log(await ethers.provider.getBlock("latest")); //put timestamp from this ouput to lime 109  array

      const initalBalance = await ethers.provider.getBalance(attacker.address);
      await this.lottery.connect(attacker).withdrawPrize();
      const finalBalance = await ethers.provider.getBalance(attacker.address);
      expect(finalBalance).to.be.gt(initalBalance);
    });

    it("Replicate same logic within the Block", async () => {
      await this.lotteryAttack.attack({ value: ethers.utils.parseEther("10") });
      await this.lottery.endLottery();
      await ethers.provider.send("evm_mine");

      console.log(
        "Attacker number:",
        await this.lottery.bets(this.lotteryAttack.address)
      );
      console.log("Winning number:", await this.lottery.winnerNumber());
    });
  });
});
