const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("delegatecall", () => {
  it("ckeck delegate call", async () => {
    let deployer = await ethers.getSigners();

    const Callee = await ethers.getContractFactory("Callee");
    this.callee = await Callee.deploy();

    const Caller = await ethers.getContractFactory("Caller");
    this.caller = await Caller.deploy();
    expect(await this.caller.callee()).to.equal(
      "0x0000000000000000000000000000000000000000"
    );
    await this.caller.setCallee(this.callee.address);
    expect(await this.caller.callee()).to.equal(this.callee.address);
    await this.caller.callSetX(5);
    expect(await this.callee.x()).to.eq(5);
    await this.caller.delegatecallSetX(50);
    expect(await this.callee.x()).to.eq(5);
    expect(await this.caller.x()).to.eq(50);
  });
});
