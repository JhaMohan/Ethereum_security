const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Upgradable Proxy Contract", () => {
  let deployer, user;

  beforeEach(async () => {
    [deployer, user] = await ethers.getSigners();

    const LogicV1 = await ethers.getContractFactory("LogicV1", deployer);
    this.logicv1 = await LogicV1.deploy();

    const Proxy = await ethers.getContractFactory("Proxy", deployer);
    this.proxy = await Proxy.deploy(this.logicv1.address);

    const LogicV2 = await ethers.getContractFactory("LogicV2");
    this.logicv2 = await LogicV2.deploy();

    this.proxyPattern = await ethers.getContractAt(
      "LogicV1",
      this.proxy.address
    );

    this.proxyPattern2 = await ethers.getContractAt(
      "LogicV2",
      this.proxy.address
    );
  });

  describe("Proxy", () => {
    it("logic contract address should be LogicV1", async () => {
      expect(await this.proxy.logicContract()).to.equal(this.logicv1.address);
    });
    it("should revert when other than owner try to update logic contract ", async () => {
      await expect(
        this.proxy.connect(user).upgrade(user.address)
      ).to.be.revertedWith("Access restricted");
    });
    it("calling increaseX of logicV1 should add 1 to x proxy's state", async () => {
      await this.proxyPattern.connect(user).increaseX();
      expect(await this.logicv1.x()).to.eq(0);
      expect(await this.proxy.x()).to.eq(1);
    });

    it("calling increaseX of logicV2 should add 2 to x proxy's state", async () => {
      await this.proxy.upgrade(this.logicv2.address);
      await this.proxyPattern2.connect(user).increaseX();
      expect(await this.logicv2.x()).to.eq(0);
      expect(await this.proxy.x()).to.eq(2);
    });
    it("Should set Y", async () => {
      await this.proxy.upgrade(this.logicv2.address);
      await this.proxyPattern2.setY(5); // as there is no y in proxy so it write in second slot which is owner slot
      expect(await this.logicv2.y()).to.eq(0);
      //   expect(await this.proxy.owner()).to.eq(deployer.address);
      //   expect(await this.proxy.y()).to.eq(5);
      //   expect(await this.proxy.owner()).to.eq(
      //     "0x0000000000000000000000000000000000000005"
      //   );

      const bytesY = await ethers.provider.getStorageAt(this.proxy.address, 3);
      const y = await ethers.BigNumber.from(bytesY);
      expect(y).to.eq(5);
    });
  });
});
