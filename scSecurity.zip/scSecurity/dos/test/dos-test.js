const { ether, ethers } = require("hardhat");
const { expect } = require("chai");

describe("DOS", () => {
  let deployer, user, attacker;

  beforeEach(async () => {
    [deployer, attacker, user] = await ethers.getSigners();
    const Auction = await ethers.getContractFactory("Auction", deployer);
    this.auction = await Auction.deploy();

    this.auction.bid({ value: 100 });
  });

  describe("Auction", () => {
    describe("Bid is lower than highestBid", () => {
      it("should not accept lower bid", async () => {
        await expect(
          this.auction.connect(user).bid({ value: 100 })
        ).to.be.revertedWith("not enough balance to bid");
      });
    });
    describe("Bid is higher than highestBid", () => {
      it("should  accept  bid", async () => {
        await this.auction.connect(user).bid({ value: 150 });
        expect(await this.auction.highestBid()).to.eq(150);
        expect(await this.auction.currentLeader()).to.eq(user.address);
      });
      it("should  add pervious bidder to array", async () => {
        await this.auction.connect(user).bid({ value: 150 });
        [addr, amount] = await this.auction.refunds(0);
        expect(addr).to.equal(deployer.address);
        expect(amount).to.eq(100);
      });
    });

    describe("refund All", () => {
      it("Should refund the bidder that didn't win", async () => {
        await this.auction.connect(user).bid({ value: 150 });
        await this.auction.bid({ value: 200 });
        const userBalance = await ethers.provider.getBalance(user.address);
        await this.auction.refund();
        const userBalnceAfter = await ethers.provider.getBalance(user.address);
        expect(userBalnceAfter).to.eq(userBalance.add(150));
      });

      it("Should revert if the amount of computation hits the block gas limit", async () => {
        for (i = 0; i < 5000; i++) {
          await this.auction.connect(attacker).bid({ value: 150 + i });
        }
        await expect(this.auction.refund()).to.be.revertedWith(
          "Transaction ran out of gas"
        );
      });
    });
  });
});
