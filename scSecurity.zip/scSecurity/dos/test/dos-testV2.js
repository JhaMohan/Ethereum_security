const { ether, ethers } = require("hardhat");
const { expect } = require("chai");

describe("DOS", () => {
  let deployer, user, attacker;

  beforeEach(async () => {
    [deployer, attacker, user] = await ethers.getSigners();
    const AuctionV2 = await ethers.getContractFactory("AuctionV2", deployer);
    this.auctionV2 = await AuctionV2.deploy();

    this.auctionV2.bid({ value: 100 });
  });

  describe("AuctionV2", () => {
    describe("Bid is lower than highestBid", () => {
      it("should not accept lower bid", async () => {
        await expect(
          this.auctionV2.connect(user).bid({ value: 100 })
        ).to.be.revertedWith("not enough balance to bid");
      });
    });
    describe("Bid is higher than highestBid", () => {
      it("should  accept  bid", async () => {
        await this.auctionV2.connect(user).bid({ value: 150 });
        expect(await this.auctionV2.highestBid()).to.eq(150);
        expect(await this.auctionV2.currentLeader()).to.eq(user.address);
      });
      it("should  add pervious bidder to mapping", async () => {
        await this.auctionV2.connect(user).bid({ value: 150 });
        amount = await this.auctionV2.refunds(deployer.address);
        expect(amount).to.eq(100);
      });
    });

    describe("refund All", () => {
      it("Should refund the bidder that didn't win", async () => {
        await this.auctionV2
          .connect(user)
          .bid({ value: ethers.utils.parseEther("500") });
        await this.auctionV2.bid({ value: ethers.utils.parseEther("600") });
        const userBalance = await ethers.provider.getBalance(user.address);
        await this.auctionV2.connect(user).withdrawBid();
        const userBalanceAfter = await ethers.provider.getBalance(user.address);
        expect(userBalanceAfter).to.gt(userBalance);
      });

      it("user should refunded for a large bid process", async () => {
        for (i = 0; i < 500; i++) {
          await this.auctionV2.connect(attacker).bid({ value: 150 + i });
        }
        await this.auctionV2.withdrawBid();
      });
    });
  });
});
