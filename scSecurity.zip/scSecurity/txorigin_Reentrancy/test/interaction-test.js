const { ether, ethers } = require("hardhat");
const { expect } = require("chai");
const {
  isCallTrace,
} = require("hardhat/internal/hardhat-network/stack-traces/message-trace");

describe("Saving contract", () => {
  let deployer, user;

  beforeEach(async () => {
    [deployer, user] = await ethers.getSigners();
    const SavingAccount = await ethers.getContractFactory("SavingAccount");
    this.savingaccount = await SavingAccount.deploy();

    const Investor = await ethers.getContractFactory("Investor");
    this.investor = await Investor.deploy(this.savingaccount.address);
  });
  describe("From an EOA", () => {
    it("should be possible to deposite", async () => {
      expect(await this.savingaccount.balanceOf(user.address)).to.equal(0);
      await this.savingaccount.connect(user).deposite({ value: 100 });
      expect(await this.savingaccount.balanceOf(user.address)).to.equal(100);
    });
    it("should be possible to withdraw", async () => {
      expect(await this.savingaccount.balanceOf(user.address)).to.equal(0);
      await this.savingaccount.connect(user).deposite({ value: 100 });
      expect(await this.savingaccount.balanceOf(user.address)).to.equal(100);
      await this.savingaccount.connect(user).withdraw();
      expect(await this.savingaccount.balanceOf(user.address)).to.equal(0);
    });
  });

  describe("From a contract", () => {
    it("should be possible to deposite", async () => {
      expect(
        await this.savingaccount.balanceOf(this.investor.address)
      ).to.equal(0);
      await this.investor.depositeIntoSavingAccount({ value: 100 });
      expect(
        await this.savingaccount.balanceOf(this.investor.address)
      ).to.equal(100);
    });
    it("should be possible to withdraw", async () => {
      expect(
        await this.savingaccount.balanceOf(this.investor.address)
      ).to.equal(0);
      await this.investor.depositeIntoSavingAccount({ value: 100 });
      expect(
        await this.savingaccount.balanceOf(this.investor.address)
      ).to.equal(100);
      await this.investor.withdrawFromSavingAccount();
      expect(
        await this.savingaccount.balanceOf(this.investor.address)
      ).to.equal(0);
    });
  });
});
