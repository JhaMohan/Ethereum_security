const { ether, ethers } = require("hardhat");
const { expect } = require("chai");
const {
  isCallTrace,
} = require("hardhat/internal/hardhat-network/stack-traces/message-trace");

describe("Tx.origin", () => {
  let deployer, user, attacker;

  beforeEach(async () => {
    [deployer, attacker, user] = await ethers.getSigners();
    const SmallWallet = await ethers.getContractFactory(
      "SmallWallet",
      deployer
    );
    this.smallwallet = await SmallWallet.deploy();
    await deployer.sendTransaction({
      to: this.smallwallet.address,
      value: 1000,
    });
    const Attacker = await ethers.getContractFactory("Attacker", attacker);
    this.attacker = await Attacker.deploy(this.smallwallet.address);
  });

  describe("Small Wallet", () => {
    it("should accept deposite", async () => {
      expect(
        await ethers.provider.getBalance(this.smallwallet.address)
      ).to.equal(1000);
    });
    it("should able to withdraw from owner account", async () => {
      const initialBalance = await ethers.provider.getBalance(user.address);
      await this.smallwallet.withdrawAll(user.address);
      expect(
        await ethers.provider.getBalance(this.smallwallet.address)
      ).to.equal(0);
      expect(await ethers.provider.getBalance(user.address)).to.equal(
        initialBalance.add(1000)
      );
    });

    it("Should withdraw revert from other account", async () => {
      await expect(
        this.smallwallet.connect(attacker).withdrawAll(attacker.address)
      ).to.be.revertedWith("not authorize");
    });
  });

  describe("Attack", () => {
    it("Should drain the victim out if smallWallet send ether", async () => {
      const initialBalance = await ethers.provider.getBalance(attacker.address);
      await deployer.sendTransaction({
        to: this.attacker.address,
        value: 1,
      });

      expect(
        await ethers.provider.getBalance(this.smallwallet.address)
      ).to.equal(0);

      expect(await ethers.provider.getBalance(attacker.address)).to.equal(
        initialBalance.add(1000)
      );
    });
  });
});
