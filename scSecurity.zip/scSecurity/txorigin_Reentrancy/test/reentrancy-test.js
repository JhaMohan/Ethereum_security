const { ether, ethers } = require("hardhat");
const { expect } = require("chai");

describe("SavingAccountV2", () => {
  let deployer, user, attacker;

  beforeEach(async () => {
    [deployer, user, attacker] = await ethers.getSigners();
    const SavingAccountV2 = await ethers.getContractFactory(
      "SavingAccountV2",
      deployer
    );
    this.savingaccountv2 = await SavingAccountV2.deploy();

    await this.savingaccountv2.deposite({
      value: ethers.utils.parseEther("100"),
    });
    await this.savingaccountv2
      .connect(user)
      .deposite({ value: ethers.utils.parseEther("50") });

    const InvestorV2 = await ethers.getContractFactory("InvestorV2", attacker);
    this.investorv2 = await InvestorV2.deploy(this.savingaccountv2.address);
  });
  describe("From an EOA", () => {
    it("should be possible to deposite", async () => {
      expect(await this.savingaccountv2.balanceOf(deployer.address)).to.equal(
        ethers.utils.parseEther("100")
      );
      expect(await this.savingaccountv2.balanceOf(user.address)).to.equal(
        ethers.utils.parseEther("50")
      );
    });
    it("should be possible to withdraw", async () => {
      await this.savingaccountv2.withdraw();
      expect(await this.savingaccountv2.balanceOf(deployer.address)).to.equal(
        0
      );
      expect(await this.savingaccountv2.balanceOf(user.address)).to.equal(
        ethers.utils.parseEther("50")
      );
    });

    it("Investor attack", async () => {
      console.log("");
      console.log("**before**");
      console.log(
        `saving account balance:
        ${ethers.utils.formatEther(
          await ethers.provider.getBalance(this.savingaccountv2.address)
        )}`
      );
      console.log(
        `attacker balance:${ethers.utils.formatEther(
          await ethers.provider.getBalance(attacker.address)
        )}`
      );

      await this.investorv2
        .connect(attacker)
        .attack({ value: ethers.utils.parseEther("10") });
      console.log("");
      console.log("**after**");
      console.log(
        `saving account balance:${ethers.utils.formatEther(
          await ethers.provider.getBalance(this.savingaccountv2.address)
        )}`
      );
      console.log(
        `attacker balance: ${ethers.utils.formatEther(
          await ethers.provider.getBalance(attacker.address)
        )}`
      );
      expect(
        await ethers.provider.getBalance(this.savingaccountv2.address)
      ).to.equal(0);
    });
  });
});
