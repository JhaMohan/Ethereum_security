const { ethers } = require("hardhat");
const { expect } = require("chai");

describe("Replay Attack", () => {
    let deployer, adminOne, adminTwo, user, attacker;

    beforeEach(async () => {
        [deployer, adminOne, adminTwo, user, attacker] = await ethers.getSigners();

        const MultiSigWallet = await ethers.getContractFactory(
            "MultiSigWallet",
            deployer
        );

        this.multiSigWallet = await MultiSigWallet.deploy([
            adminOne.address,
            adminTwo.address
        ]);
        const MultiSigWalletV2 = await ethers.getContractFactory(
            "MultiSigWalletV2",
            deployer
        );

        this.multiSigWalletV2 = await MultiSigWalletV2.deploy([
            adminOne.address,
            adminTwo.address
        ]);


        await adminOne.sendTransaction({
            to: this.multiSigWallet.address,
            value: ethers.utils.parseEther("20"),
        });


        await adminOne.sendTransaction({
            to: this.multiSigWalletV2.address,
            value: ethers.utils.parseEther("20"),
        });
    });

    describe("Multisig Wallet", () => {
        it("should allow transfer fund after receiving both signature", async () => {
            const before = await ethers.provider.getBalance(user.address);
            const amount = ethers.utils.parseEther("5");

            //Message encode
            const message = ethers.utils.solidityPack(
                ["address", "uint256"],
                [user.address, amount]
            );
            const messageBuffer = ethers.utils.concat([message]);

            //Sign the message
            let adminOneSig = await adminOne.signMessage(messageBuffer);
            let adminTwoSig = await adminTwo.signMessage(messageBuffer);

            //Split signature
            let adminOneSplitSig = ethers.utils.splitSignature(adminOneSig);
            let adminTwoSplitSig = ethers.utils.splitSignature(adminTwoSig);

            await this.multiSigWallet.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ]);

            const after = await ethers.provider.getBalance(user.address);

            expect(after).to.eq(before.add(ethers.utils.parseEther("5")));
        });

        it("should revert if other than then admin sign tx", async () => {
            const before = await ethers.provider.getBalance(user.address);
            const amount = ethers.utils.parseEther("5");

            //Message encode
            const message = ethers.utils.solidityPack(
                ["address", "uint256"],
                [user.address, amount]
            );
            const messageBuffer = ethers.utils.concat([message]);

            //Sign the message
            let adminOneSig = await attacker.signMessage(messageBuffer);
            let adminTwoSig = await adminTwo.signMessage(messageBuffer);

            //Split signature
            let adminOneSplitSig = ethers.utils.splitSignature(adminOneSig);
            let adminTwoSplitSig = ethers.utils.splitSignature(adminTwoSig);

            await expect(this.multiSigWallet.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ])).to.be.revertedWith("Access restricted");

        });

        it("Replay Attack", async () => {
            const before = await ethers.provider.getBalance(user.address);
            const amount = ethers.utils.parseEther("5");

            const nonce = 1;
            //Message encode
            const message = ethers.utils.solidityPack(
                ["address", "uint256"],
                [user.address, amount]
            );
            const messageBuffer = ethers.utils.concat([message]);

            //Sign the message
            let adminOneSig = await adminOne.signMessage(messageBuffer);
            let adminTwoSig = await adminTwo.signMessage(messageBuffer);

            //Split signature
            let adminOneSplitSig = ethers.utils.splitSignature(adminOneSig);
            let adminTwoSplitSig = ethers.utils.splitSignature(adminTwoSig);

            await this.multiSigWallet.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ]);

            await this.multiSigWallet.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ]);

            const after = await ethers.provider.getBalance(user.address);

            expect(after).to.eq(before.add(ethers.utils.parseEther("10")));
        });



        it("Replay Attack on V2", async () => {
            const before = await ethers.provider.getBalance(user.address);
            const amount = ethers.utils.parseEther("5");

            const nonce = 1;
            //Message encode
            const message = ethers.utils.solidityPack(
                ["address", "uint256"],
                [user.address, amount]
            );
            const messageBuffer = ethers.utils.concat([message]);

            //Sign the message
            let adminOneSig = await adminOne.signMessage(messageBuffer);
            let adminTwoSig = await adminTwo.signMessage(messageBuffer);

            //Split signature
            let adminOneSplitSig = ethers.utils.splitSignature(adminOneSig);
            let adminTwoSplitSig = ethers.utils.splitSignature(adminTwoSig);

            await this.multiSigWalletV2.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ], nonce);

            await expect(this.multiSigWalletV2.transfer(user.address, amount, [
                adminOneSplitSig,
                adminTwoSplitSig
            ], nonce)).to.be.revertedWith("Signature expired");

            const after = await ethers.provider.getBalance(user.address);

            expect(after).to.eq(before.add(ethers.utils.parseEther("5")));
        });
    });
});
